<?php

$_["heading_title"] = "SQLantern";

$_["text_extensions"] = "Extensions";
$_["text_modules"] = "Modules";

$_["text_status"] = "Status";

$_["text_status_hint"] = "When enabled, a new `System -> SQLantern` menu item is added into the dashboard menu (for the users who belong to the user group, which has rights to modify this module)";

$_["text_success"] = "Module has been saved";

$_["error_permission"] = "Not enough rights to make changes";

//